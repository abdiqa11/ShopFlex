import CreateStoreScreen from '../screens/CreateStoreScreen';

export default function CreateStorePage() {
  return <CreateStoreScreen />;
}

