import WelcomeScreen from '../screens/WelcomeScreen';

export default function Index() {
  return <WelcomeScreen />;
}
