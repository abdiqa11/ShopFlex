import StoreListScreen from '../screens/StoreListScreen';

export default function StoreListPage() {
    return <StoreListScreen />;
}
