import SignInScreen from '../screens/SignInScreen';
export default function SignInPage() {
    return <SignInScreen />;
}
